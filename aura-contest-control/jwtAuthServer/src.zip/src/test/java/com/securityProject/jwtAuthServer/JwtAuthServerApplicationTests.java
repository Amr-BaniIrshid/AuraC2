package com.securityProject.jwtAuthServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
