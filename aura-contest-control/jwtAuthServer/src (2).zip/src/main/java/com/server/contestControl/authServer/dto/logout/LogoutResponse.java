package com.server.contestControl.authServer.dto.logout;

public record LogoutResponse(String message) {}
