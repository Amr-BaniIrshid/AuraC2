package com.server.contestControl.authServer.service.user;

import com.server.contestControl.authServer.entity.User;
import com.server.contestControl.authServer.exception.api.DuplicateUsernameException;
import com.server.contestControl.authServer.exception.api.UserNotFoundException;
import com.server.contestControl.authServer.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;


    public Optional<User> findByEmail(String email) {
        return userRepository.findByUsername(email);
    }

    public void assertUsernameNotExists(String username) {
        if (userRepository.existsByUsername(username)) {
            throw new DuplicateUsernameException(username);
        }
    }

    public User getUserByUsernameOrThrow(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException(username));
    }

    public User save(User user) {
        return userRepository.save(user);
    }


}
