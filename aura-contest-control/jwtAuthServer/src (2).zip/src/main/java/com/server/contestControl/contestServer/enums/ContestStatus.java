package com.server.contestControl.contestServer.enums;

public enum ContestStatus {
    UPCOMING,
    RUNNING,
    PAUSED,
    ENDED
}
