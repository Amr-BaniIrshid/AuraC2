package com.server.contestControl.authServer.dto.register;

import lombok.*;

@Getter
@Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RegisterResponse {
    private String message;
}
