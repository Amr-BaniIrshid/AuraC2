package com.server.contestControl.authServer.enums;

public enum TokenType {
    ACCESS, REFRESH
}
