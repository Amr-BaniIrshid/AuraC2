package com.server.contestControl.submissionServer.queue.result;

public class ResultConsumer {
}
